<?php
	define('HOSTNAME', 'localhost');
	define('USERNAME', 'sipadude_db');
	define('PASSWORD', 'samba@2020');
	define('DB_SELECT', 'sipadude_db');

	$koneksi = new mysqli(HOSTNAME,USERNAME,PASSWORD,DB_SELECT) or die(mysqli_errno());


?>